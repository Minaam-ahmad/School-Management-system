package Restaurant;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Update extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField nam;
	private JTextField fathername;
	private JTextField salary;

	/**
	 * Launch the application.
	 */
	public static Update frame;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new Update();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Update() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 734, 469);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.setBounds(80, 10, 284, 339);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel names = new JLabel("Name");
		names.setFont(new Font("Tahoma", Font.BOLD, 14));
		names.setBounds(10, 44, 79, 14);
		panel.add(names);
		
		JLabel lblFathername = new JLabel("Fathername");
		lblFathername.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFathername.setBounds(10, 83, 89, 14);
		panel.add(lblFathername);
		
		JLabel lblSalary = new JLabel("Salary");
		lblSalary.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSalary.setBounds(10, 120, 79, 14);
		panel.add(lblSalary);
		
		JLabel lblExperience = new JLabel("Experience");
		lblExperience.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblExperience.setBounds(10, 161, 79, 14);
		panel.add(lblExperience);
		
		nam = new JTextField();
		nam.setBounds(99, 43, 154, 20);
		panel.add(nam);
		nam.setColumns(10);
		
		fathername = new JTextField();
		fathername.setBounds(99, 82, 154, 20);
		panel.add(fathername);
		fathername.setColumns(10);
		
		salary = new JTextField();
		salary.setBounds(99, 119, 154, 20);
		panel.add(salary);
		salary.setColumns(10);
		
		JFormattedTextField experience = new JFormattedTextField();
		experience.setBounds(99, 160, 154, 20);
		panel.add(experience);
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection con ;
			
				String path="jdbc:mysql://127.0.0.1:3306/Manag";
			    String name="root";
			    String password="";
			    
				String c,d,f,g;
				
	c=(String)nam.getText();
	d=(String)fathername.getText();
	f=(String) salary.getText();
	g=(String) experience.getText();
			String query= "UPDATE teachers SET Salary= ?, Experience=? WHERE Name=? AND Fathername=?;";

			try
			{
				con=DriverManager.getConnection(path,name ,password);
			 PreparedStatement preparedStatement = con.prepareStatement(query);
			    preparedStatement.setString(1, f);
			    preparedStatement.setString(2, g);
			    preparedStatement.setString(3, c);
			    preparedStatement.setString(4, d);

			    int i = preparedStatement.executeUpdate();
			  //  System.out.println("Rows affected: " + i);

			    preparedStatement.close();
			} 
			catch (SQLException e1) {
			    e1.printStackTrace();
			
				}
			}
				
			
		});
		btnNewButton.setBackground(new Color(128, 255, 128));
		btnNewButton.setForeground(new Color(0, 0, 128));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(116, 238, 105, 23);
		panel.add(btnNewButton);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection con;
				String path="jdbc:mysql://127.0.0.1:3306/Manag";
			    String name="root";
			    String password="";
			   
					String c,d,f,g;
					
					c=(String)nam.getText();
					d=(String)fathername.getText();
//				f=(String) salary.getText();
//				g=(String) experience.getText();
				String query= "DELETE FROM teachers WHERE Name=? AND Fathername=?;";

				try
				{
					con=DriverManager.getConnection(path,name ,password);
				 PreparedStatement preparedStatement = con.prepareStatement(query);
				    preparedStatement.setString(1, c);
				    preparedStatement.setString(2, d);
				   

				    int i = preparedStatement.executeUpdate();
				   System.out.println("Rows affected: " + i);

				    preparedStatement.close();
				} 
				catch (SQLException e1) {
				    e1.printStackTrace();
				
					}
					
			}
				
			
		});
		btnDelete.setForeground(new Color(0, 0, 128));
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnDelete.setBackground(new Color(128, 255, 128));
		btnDelete.setBounds(116, 279, 105, 23);
		panel.add(btnDelete);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				wel_page();
			}
		});
		btnBack.setForeground(new Color(0, 0, 128));
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnBack.setBackground(new Color(128, 255, 128));
		btnBack.setBounds(90, 352, 105, 23);
		contentPane.add(btnBack);
	}
	public void wel_page() {
		Welcome w=new Welcome();
		w.setVisible(true);
		frame.setVisible(false);
	}

}
