package Restaurant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Firstcode {
	Connection con;

	public void conect() {
	String path="jdbc:mysql://127.0.0.1:3306/manag";
    String name="root";
    String password="";
    try {
		con=DriverManager.getConnection(path,name ,password);
		System.out.println("");
	     }
    catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	     } 
    }
    public void insert( String name,String pass,String email) {
    	String query="INSERT INTO logind (Name,Password,Email)VALUES('"+name+"','"+ pass+"','"+email+"')";
    		Statement s;
    		
    		try {
    			s = con.createStatement();
    			s.executeUpdate(query);
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();}
    		}
    public int select(String user,String pass)
    		   {  
    			String query = "SELECT * FROM logind WHERE Name = '" + user + "' AND Password = '" + pass + "'";

 
    			
    			Statement s;
    			try {
    				s = con.createStatement();
    			ResultSet rs =s.executeQuery(query);
    			if (rs.next()== false) {
    				return -1;
    			}
    			}
    			catch (SQLException e)
    			{
    				  
    				e.printStackTrace();
    			}
    			return 0;
    		} 
    		public void insert(String name,String fname,String cnic,String email,String gender,String salary,String exp,String quali,String phone,String address) {
    			
    			String query="INSERT INTO teachers(Name,Fathername,Gender,Qualification,CNIC,Email,Phoneno,Salary,Experience,Address)VALUES('"+name+"','"+fname+"','"+gender+"','"+quali+"','"+cnic+"','"+email+"','"+phone+"','"+salary+"','"+exp+"','"+address+"')";
    			Statement s;
    			
    			try {
    				s=con.createStatement();
    				s.executeUpdate(query);
    				System.out.println(query);
    			} catch (SQLException e) {
    				e.printStackTrace();}
    			}
    		 public int select2(String user,String pass)
  		   {  
  			String query = "SELECT * FROM teachers WHERE Name = '" + user + "' AND Password = '" + pass + "'";


  			
  			Statement s;
  			try {
  				s = con.createStatement();
  			ResultSet rs =s.executeQuery(query);
  			if (rs.next()== false) {
  				return -1;
  			}
  			}
  			catch (SQLException e)
  			{
  				  
  				e.printStackTrace();
  			}
  			return 0;
  		} 
    		 public void insert2( String name,String email,String pass) {
    		    	String query="INSERT INTO teachers (Name,Email,Password)VALUES('"+name+"','"+email+"','"+ pass+"')";
    		    		Statement s;
    		    		
    		    		try {
    		    			s = con.createStatement();
    		    			s.executeUpdate(query);
    		    		} catch (SQLException e) {
    		    			// TODO Auto-generated catch block
    		    			e.printStackTrace();}
    		    		}
}
