package Restaurant;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Loginform extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JLabel lblNewLabel_1;
	private JTextField password;
	private JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */ 
	public static Loginform frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new Loginform();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Loginform() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 729, 462);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		panel.setBackground(new Color(128, 255, 255));
		panel.setBounds(250, 99, 250, 271);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 63, 82, 14);
		panel.add(lblNewLabel);
		
		name = new JTextField();
		name.setBounds(102, 62, 138, 20);
		panel.add(name);
		name.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 121, 82, 14);
		panel.add(lblNewLabel_1);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBounds(102, 120, 138, 20);
		panel.add(password);
		
		lblNewLabel_2 = new JLabel("Register,new account");
		lblNewLabel_2.setBounds(26, 213, 165, 14);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Log-in");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBackground(new Color(128, 255, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Firstcode f=new Firstcode();
				f.conect();
				f.select(name.getText(), password.getText());
				boolean		y=name.getText().isEmpty();
				boolean z=password.getText() != null;
			//	 if(name.getText().isBlank()^ password.getText().isBlank()) {
			//		 JOptionPane.showMessageDialog(contentPane, "Enter name,Email and password", "Error",JOptionPane.ERROR_MESSAGE);}
				if(y==true& z==true) {
					JOptionPane.showMessageDialog(contentPane, "Enter name,Email and password", "Error",JOptionPane.ERROR_MESSAGE);
				}
				 else {
					 int i=f.select(name.getText(), password.getText());
					 if(i==-1) {
						JOptionPane.showMessageDialog(contentPane, "in valid user name or password", "Error",JOptionPane.ERROR_MESSAGE);	
						}
					
					
						else {
							
							try {
							Wel_page();}
						catch(NullPointerException e2)	{
								
							}
						}
						
					}}
				
					
		
			
		});
		btnNewButton.setForeground(new Color(0, 0, 255));
		btnNewButton.setBounds(127, 179, 113, 23);
		panel.add(btnNewButton);
		
		JButton btnSignup = new JButton("Sign-up");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register_page();
				
			}
		});
		btnSignup.setForeground(Color.BLUE);
		btnSignup.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnSignup.setBackground(new Color(128, 255, 0));
		btnSignup.setBounds(127, 237, 113, 23);
		panel.add(btnSignup);
		
		JLabel lblNewLabel_3 = new JLabel("Log in");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(62, 11, 129, 29);
		panel.add(lblNewLabel_3);
	}
public void Wel_page() {
	Welcome w=new Welcome();
	w.setVisible(true);
	frame.setVisible(false);
}
public void Register_page() {
	Registerform r=new Registerform();
	r.setVisible(true);
	frame.setVisible(false);
}
}

