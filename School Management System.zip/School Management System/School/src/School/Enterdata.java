package Restaurant;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Enterdata extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField fathername;
	private JTextField email;
	private JTextField quali;

	/**
	 * Launch the application.
	 */
	public static Enterdata frame;
	private JTextField cnic;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new Enterdata();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Enterdata() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 697, 476);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel.setForeground(new Color(64, 0, 64));
		panel.setBounds(163, 11, 495, 361);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(30, 24, 92, 14);
		panel.add(lblNewLabel);
		
		JLabel lblFathername = new JLabel("Fathername");
		lblFathername.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFathername.setBounds(30, 53, 92, 14);
		panel.add(lblFathername);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGender.setBounds(30, 89, 92, 14);
		panel.add(lblGender);
		
		JLabel lblQualification = new JLabel("Qualification");
		lblQualification.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblQualification.setBounds(30, 120, 92, 14);
		panel.add(lblQualification);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEmail.setBounds(30, 170, 92, 14);
		panel.add(lblEmail);
		
		JLabel lblPhoneNo = new JLabel("Phone no.");
		lblPhoneNo.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPhoneNo.setBounds(30, 201, 92, 14);
		panel.add(lblPhoneNo);
		
		JLabel lblExperience = new JLabel("Experience");
		lblExperience.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblExperience.setBounds(30, 236, 92, 14);
		panel.add(lblExperience);
		
		name = new JTextField();
		name.setBounds(146, 23, 167, 20);
		panel.add(name);
		name.setColumns(10);
		
		fathername = new JTextField();
		fathername.setColumns(10);
		fathername.setBounds(146, 52, 167, 20);
		panel.add(fathername);
		
		JRadioButton male = new JRadioButton("Male");
		male.setBounds(146, 87, 109, 23);
		panel.add(male);
		
		JRadioButton female = new JRadioButton("Female");
		female.setBounds(268, 87, 109, 23);
		panel.add(female);
		
		email = new JTextField();
		email.setBounds(146, 170, 167, 20);
		panel.add(email);
		email.setColumns(10);
		
		JFormattedTextField phone = new JFormattedTextField();
		phone.setBounds(146, 200, 167, 20);
		panel.add(phone);
		
		JFormattedTextField exper = new JFormattedTextField();
		exper.setBounds(146, 230, 167, 20);
		panel.add(exper);
		
		quali = new JTextField();
		quali.setColumns(10);
		quali.setBounds(146, 120, 167, 20);
		panel.add(quali);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddress.setBounds(30, 296, 92, 14);
		panel.add(lblAddress);
		
		JTextArea address = new JTextArea();
		address.setBounds(146, 293, 167, 65);
		panel.add(address);
		
		JLabel lblSalary = new JLabel("Salary");
		lblSalary.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSalary.setBounds(30, 261, 92, 14);
		panel.add(lblSalary);
		
		JFormattedTextField salary = new JFormattedTextField();
		salary.setBounds(146, 260, 167, 20);
		panel.add(salary);
		
		JLabel lblCnic = new JLabel("CNIC");
		lblCnic.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblCnic.setBounds(30, 145, 92, 14);
		panel.add(lblCnic);
		
		cnic = new JTextField();
		cnic.setColumns(10);
		cnic.setBounds(146, 144, 167, 20);
		panel.add(cnic);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton.setBackground(new Color(128, 255, 128));
		btnNewButton.setForeground(new Color(0, 0, 128));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(383, 403, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Gender;
				male.setSelected(true);
				ButtonGroup bg=new ButtonGroup();
				bg.add(male);
				bg.add(female);
				if(male.isSelected()) {
					Gender="male";
				}
				else {
					Gender="female";
				}
				Firstcode f=new Firstcode();
			f.conect();
	if(name.getText().isEmpty()^fathername.getText().isEmpty()) {
		
	}
	else {
			f.insert(name.getText(),fathername.getText(),Gender,quali.getText(),cnic.getText(),email.getText(),phone.getText(),exper.getText(),salary.getText(),address.getText());
				
			}}
		});
		btnSubmit.setForeground(new Color(0, 0, 128));
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnSubmit.setBackground(new Color(128, 255, 128));
		btnSubmit.setBounds(512, 404, 89, 23);
		contentPane.add(btnSubmit);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				wel_page();
			}
		});
		btnNewButton_1.setForeground(new Color(0, 0, 128));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton_1.setBackground(new Color(128, 255, 128));
		btnNewButton_1.setBounds(79, 404, 89, 23);
		contentPane.add(btnNewButton_1);
	}
	
	public void wel_page() {
		Welcome w=new Welcome();
		w.setVisible(true);
		frame.setVisible(false);
	}
}
