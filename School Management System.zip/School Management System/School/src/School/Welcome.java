package Restaurant;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Welcome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	String Task;
	/**
	 * Launch the application.
	 */
	public static Welcome frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new Welcome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
			

	/**
	 * Create the frame.
	 */
	public Welcome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 781, 486);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(128, 255, 255));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		panel.setBounds(194, 60, 311, 319);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Techer record Managment System");
		lblNewLabel.setForeground(new Color(0, 0, 160));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(5, 11, 311, 55);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Please, Click at one option :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(20, 105, 241, 20);
		panel.add(lblNewLabel_1);
		
		JRadioButton enter = new JRadioButton("Enter new Data");
		enter.setFont(new Font("Tahoma", Font.BOLD, 12));
		enter.setBounds(76, 140, 150, 23);
		panel.add(enter);
		
		JRadioButton update = new JRadioButton("Update");
		update.setFont(new Font("Tahoma", Font.BOLD, 12));
		update.setBounds(76, 179, 150, 23);
		panel.add(update);
		
		JRadioButton delete = new JRadioButton("Delete");
		delete.setFont(new Font("Tahoma", Font.BOLD, 12));
		delete.setBounds(76, 221, 150, 23);
		panel.add(delete);
		
		JButton btnNewButton = new JButton("Click First");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ButtonGroup bg=new ButtonGroup();
				bg.add(enter);
				bg.add(update);
				bg.add(delete);
				
				enter.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (enter.isSelected()) {
							Enter_page();
						}
					}
				});

				update.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (update.isSelected()) {
							Update_page();
						}
					}
				});

				delete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (delete.isSelected()) {
							Update_page();
						}
					}
				});
			}
//				if(enter.isSelected()) {
//					Enter_page();
//				}
//				else if(update.isSelected()) {
//					Update_page();
//				}
//				else {
//					Update_page();
//				}
//			}
		});
		btnNewButton.setBackground(new Color(128, 255, 128));
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton.setBounds(76, 61, 145, 23);
		panel.add(btnNewButton);
	}
	public void Enter_page() {
		Enterdata en=new Enterdata();
		en.setVisible(true);
		frame.setVisible(false);
	}
	public void Update_page() {
		Update up=new Update();
		up.setVisible(true);
		frame.setVisible(false);
	}}

