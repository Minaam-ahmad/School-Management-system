package Restaurant;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Registerform extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static Registerform frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new Registerform();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Registerform() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 741, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3, true));
		panel.setBackground(new Color(128, 255, 255));
		panel.setBounds(228, 23, 358, 410);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(26, 74, 95, 14);
		panel.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPassword.setBounds(26, 121, 95, 14);
		panel.add(lblPassword);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEmail.setBounds(26, 172, 95, 14);
		panel.add(lblEmail);
		
		name = new JTextField();
		name.setBounds(136, 89, 147, 20);
		panel.add(name);
		name.setColumns(10);
		
		password = new JPasswordField();
		password.setBounds(136, 140, 147, 20);
		panel.add(password);
		
		JFormattedTextField email = new JFormattedTextField();
		email.setBounds(137, 193, 146, 20);
		panel.add(email);
		
		JButton Submit = new JButton("Submit");
		Submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Firstcode f=new Firstcode();
				f.conect();
				//f.insert(name.getText(), password.getText(), email.getText());
				if(name.getText().isBlank()^password.getText().isEmpty()) {
					JOptionPane.showMessageDialog(contentPane, "Enter name,Email and password", "Error",JOptionPane.ERROR_MESSAGE);
				}
				else {
				
				f.insert(name.getText(), password.getText(), email.getText());
				Wel_page();
			}}
		});
		Submit.setBackground(new Color(128, 255, 128));
		Submit.setForeground(new Color(0, 0, 255));
		Submit.setFont(new Font("Times New Roman", Font.BOLD, 16));
		Submit.setBounds(244, 295, 89, 23);
		panel.add(Submit);
		
		JLabel lblNewLabel_3 = new JLabel("Register Form");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(103, 11, 147, 38);
		panel.add(lblNewLabel_3);
	}
	public void Wel_page() {
		Welcome w=new Welcome();
		w.setVisible(true);
		frame.setVisible(false);
		
	}
}
